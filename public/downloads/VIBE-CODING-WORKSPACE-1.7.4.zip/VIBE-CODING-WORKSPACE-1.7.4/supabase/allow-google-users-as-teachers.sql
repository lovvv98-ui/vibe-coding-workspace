-- VIBE CODING WORKSPACE 1.7.4
-- Allow any Google-authenticated user to self-register as a classroom teacher.
-- Run this once in Supabase Dashboard > SQL Editor.
-- This assumes public.classroom_teachers(user_id) already exists and user_id is unique.

ALTER TABLE public.classroom_teachers ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT ON TABLE public.classroom_teachers TO authenticated;

DROP POLICY IF EXISTS "Google users can view their own teacher row" ON public.classroom_teachers;
CREATE POLICY "Google users can view their own teacher row"
ON public.classroom_teachers
FOR SELECT
TO authenticated
USING (
  user_id = auth.uid()
  AND (auth.jwt() -> 'app_metadata' ->> 'provider') = 'google'
  AND COALESCE((auth.jwt() ->> 'is_anonymous')::boolean, false) = false
);

DROP POLICY IF EXISTS "Google users can self-register as teachers" ON public.classroom_teachers;
CREATE POLICY "Google users can self-register as teachers"
ON public.classroom_teachers
FOR INSERT
TO authenticated
WITH CHECK (
  user_id = auth.uid()
  AND (auth.jwt() -> 'app_metadata' ->> 'provider') = 'google'
  AND COALESCE((auth.jwt() ->> 'is_anonymous')::boolean, false) = false
);

-- No UPDATE or DELETE permission is granted by this script.
