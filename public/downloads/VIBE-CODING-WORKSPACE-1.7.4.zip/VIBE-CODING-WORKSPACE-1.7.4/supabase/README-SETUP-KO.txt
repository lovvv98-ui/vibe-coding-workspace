VIBE CODING WORKSPACE 1.7.4 - Supabase 자동 강사 등록 설정

1) Supabase 대시보드에서 해당 프로젝트를 엽니다.
2) SQL Editor > New query를 선택합니다.
3) 같은 폴더의 allow-google-users-as-teachers.sql 내용을 붙여넣고 Run을 누릅니다.
4) 확장 프로그램을 새로고침한 뒤 Google 계정으로 로그인합니다.

이 SQL은 public.classroom_teachers 테이블이 이미 존재하고 user_id 컬럼에 UNIQUE 제약이 있다는 전제입니다.
README-KO.txt의 기존 강사 최초 등록 절차 대신 이 스크립트를 1회 실행하면 됩니다.

권한 범위:
- Google Provider로 인증된 로그인 사용자만 허용
- 본인 auth.uid()와 같은 user_id만 INSERT/SELECT 가능
- 익명 로그인 사용자는 허용하지 않음
- UPDATE/DELETE 권한은 추가하지 않음
- service_role 키를 사용하지 않음
