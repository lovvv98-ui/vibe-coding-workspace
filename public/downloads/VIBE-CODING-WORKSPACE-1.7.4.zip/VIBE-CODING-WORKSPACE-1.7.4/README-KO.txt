VIBE CODING WORKSPACE 1.7.3

주요 기능
- ChatGPT, Lovable, GitHub, Cursor, Vercel, InfinityFree, Supabase, MOA:PULSE 온라인퍼실리테이션 대시보드 포함 8개 도구 제공
- 이미 열려 있는 서비스 탭으로 이동하고, 없는 서비스만 새 탭 생성
- 확장 프로그램 내부에 강의 채팅 기능 추가
- 수강생은 강의코드와 닉네임으로 입장 (익명 Supabase 인증은 백그라운드에서 처리)
- 강사는 Google 계정으로 로그인
- 강사는 강의방을 만들고 입장코드를 공유
- 일반 대화, 강사 공지, 실습 프롬프트 전송
- 모든 대화 메시지 오른쪽 위의 복사 아이콘으로 메시지 전체를 한 번에 복사
- Supabase 메뉴에서 강의 채팅 프로젝트 관리 화면으로 이동
- 메시지는 Supabase 데이터베이스에 저장되고 Realtime으로 수신

설치 / 업데이트 방법 (Chrome / Edge)
1. ZIP 파일의 압축을 풉니다. 압축을 풀면 `VIBE-CODING-WORKSPACE-1.7.3` 폴더 하나가 생성되며, 그 폴더 바로 안에 `manifest.json`, `sidepanel.html`, `options.html`, `data` 폴더 등이 있습니다.
2. 기존에 사용하던 확장 프로그램 폴더를 백업합니다.
3. 압축 해제된 폴더 안의 파일과 `data` 폴더를 기존 확장 프로그램 폴더에 복사해 덮어씁니다. 기존 확장 프로그램 폴더 자체를 새 폴더로 교체하지 마세요.
   - manifest.json에 설정된 Google Extension ID가 기존 확장 프로그램 ID와 일치해야 합니다.
   - 폴더 위치를 바꾸거나 새 폴더로 로드하면 개발자 모드 확장 프로그램 ID가 달라질 수 있습니다.
4. chrome://extensions/ 또는 edge://extensions/ 에 접속합니다.
5. 기존 VIBE CODING WORKSPACE 카드의 새로고침 버튼을 누릅니다.
6. 사이드 패널을 열고 아래쪽의 수업 채팅 영역을 확인합니다.

필요한 Supabase 설정
- Anonymous Sign-ins 활성화
- Google Provider 활성화: Google Cloud의 Web application Client ID/Secret을 기본값으로 설정하고 Chrome Extension Client ID도 추가 Client ID에 포함
- Web application OAuth 클라이언트의 승인된 리디렉션 URI에 `https://iokhfnkhcfgblgpgheecidpbidphebbh.chromiumapp.org`를 추가 (Supabase Callback URI도 함께 유지)
- 확장 프로그램 로그인은 Web application Client ID를 사용하며, Chrome Extension Client ID는 Supabase의 허용 Client IDs에 추가로 등록
- 제공된 SQL 스크립트로 생성한 테이블 / RPC 함수가 존재해야 함
- chat_messages 및 room_members 테이블이 supabase_realtime publication에 포함되어 있어야 함
- room_members 변경 이벤트로 닉네임과 참여자 수를 실시간 갱신

Google 강사 권한 자동 등록 (1회 설정)
1. Supabase 대시보드의 SQL Editor를 엽니다.
2. ZIP 안의 `supabase/allow-google-users-as-teachers.sql` 파일 내용을 붙여넣고 한 번 실행합니다.
3. 확장 프로그램에서 Google 로그인 버튼을 누릅니다.
4. 로그인한 Google 계정은 자신의 사용자 ID로 강사 권한 테이블에 자동 등록됩니다. 사용자 ID 복사나 개별 SQL 등록은 필요하지 않습니다.
5. 강의 제목을 입력하고 강의방 만들기를 누른 뒤 생성된 강의코드를 수강생에게 공유합니다.

자동 등록 정책은 Google Provider로 인증된 계정이 자신의 행만 추가하도록 제한합니다. 익명 수강생 계정이나 다른 사용자의 ID를 등록할 수 없으며, service_role 키는 사용하지 않습니다.

수강생 입장
1. 수업 채팅의 강의코드 입력란에 전달받은 코드를 입력합니다.
2. 닉네임을 입력하고 강의방 입장을 누릅니다.
3. 별도의 Supabase 회원가입 / Google 로그인이 필요하지 않습니다.

보안 참고
- sb_publishable 키는 공개용 클라이언트 키이며 확장 프로그램에 포함됩니다.
- sb_secret 또는 service_role 키는 절대로 확장 프로그램에 넣지 않습니다.
- DB 접근은 Supabase RLS와 RPC 권한 검사로 제어됩니다.
- 익명 계정은 브라우저 저장 데이터가 삭제되면 동일한 계정으로 복구되지 않을 수 있습니다.
- 강의코드를 외부에 공개하지 말고 강의 종료 후에는 방을 더 이상 공유하지 마세요.


[1.5.2 인증 수정 안내]
- Google 인증 시작은 공유 Service Worker에서 한 번만 실행되도록 잠금 처리했습니다.
- 여러 Side Panel에서 동시에 로그인 버튼을 눌러 Chrome의 중복 인증 흐름 오류가 나지 않도록 했습니다.
- 리디렉션 주소는 chrome.identity.getRedirectURL()로 생성합니다.
- Google Cloud Console의 Web application OAuth 클라이언트 승인된 리디렉션 URI에 아래 주소를 정확히 등록하세요(끝의 / 포함).
  https://iokhfnkhcfgblgpgheecidpbidphebbh.chromiumapp.org/
- 기존 Supabase Callback URL도 승인된 리디렉션 URI에 그대로 유지하세요.
- 이전 로그인 팝업이 남아 있으면 먼저 닫고 확장 프로그램을 새로고침하세요.


[1.5.3 참여자 닉네임 실시간 갱신 수정]
- 강사 화면이 새 참여자의 room_members INSERT/UPDATE를 실시간 구독합니다.
- 참여자 목록과 참여 인원 수를 변경 즉시 다시 불러옵니다.
- 메시지 발신자 닉네임이 아직 캐시에 없으면 참여자 목록을 한 번 더 조회합니다.
- Supabase SQL Editor에서 제공된 enable-room-members-realtime.sql을 한 번 실행해야 합니다.


[1.5.4 Supabase 도구 추가]
- 수업 도구 기본 목록 마지막에 Supabase를 추가했습니다.
- Supabase 메뉴는 현재 강의 채팅 프로젝트 대시보드로 이동합니다.
- 기존 사용자의 저장된 도구 목록에도 버전 마이그레이션으로 Supabase가 자동 추가됩니다.


[1.5.6 Codex 도구 제거]
- 수업 도구 기본 목록에서 Codex를 제거했습니다.
- 기존 설치에서 저장된 Codex 항목과 마지막 방문 주소도 업데이트 시 자동 제거됩니다.
- ChatGPT, Lovable, GitHub, Cursor, Vercel, InfinityFree, Supabase의 7개 도구는 유지됩니다.


[1.5.7 메시지 복사 아이콘 개선]
- 모든 채팅 메시지 오른쪽 위에 아이콘 전용 복사 버튼을 표시합니다.
- 일반 메시지, 공지, 실습 프롬프트 모두 전체 내용을 복사할 수 있습니다.
- 클립보드 API가 차단되는 경우 확장 프로그램 내부 대체 복사 방식을 시도합니다.
- 기본 수업 도구는 Codex를 제외한 7개(ChatGPT, Lovable, GitHub, Cursor, Vercel, InfinityFree, Supabase)입니다.


[1.5.8 MOA:PULSE 대상 페이지 추가 및 ZIP 폴더 구조 변경]
- 수업 도구 목록 맨 아래에 `MOA:PULSE 온라인퍼실리테이션 대시보드`를 추가했습니다.
- 연결 주소: https://lovvv98.page.gd/index.php?i=1
- 기존 사용자도 업데이트 시 페이지 도구가 목록의 맨 마지막에 자동 추가됩니다.
- 기본 도구 복원 기능은 8개 기본 도구를 복원합니다.
- ZIP 압축을 풀면 `VIBE-CODING-WORKSPACE-1.5.8` 폴더 안에 manifest.json 및 확장 프로그램 파일이 들어 있습니다.


[1.5.9 MOA:PULSE 도구 이름 변경]
- 마지막 수업 도구의 표시 이름을 `MOA:PULSE 온라인퍼실리테이션 대시보드`로 변경했습니다.
- 연결 주소와 기존 사용자별 설정은 유지하며, 업데이트 시 저장된 도구 이름도 자동 변경됩니다.


[1.5.11 안정 ID 업데이트]
- manifest.json에 고정 공개 키를 추가했습니다.
- 압축 해제 위치가 바뀌어도 Chrome/Edge 확장 프로그램 ID가 유지됩니다.
- 최초 업데이트 후 Google OAuth 승인 리디렉션 URI에 새 chromiumapp.org 주소를 한 번 등록해야 합니다.


[1.7.1 수정 사항]
- 바이브코딩 수업용 PPT 바로가기 높이를 일반 서비스 항목과 같은 45px로 맞췄습니다.
- 설정 페이지에 '수업 자료 > 바이브코딩 수업용 PPT' 표시 설정을 추가했습니다. 표시 여부는 저장되며 사이드 패널에 즉시 반영됩니다.
- 사이드 패널 갱신 과정에서 발생할 수 있던 미선언 변수 오류를 수정했습니다.
- ZIP 내부를 단일 최상위 폴더 구조로 정리했습니다. 압축 해제 후 폴더 안에 중복 폴더가 한 번 더 생기지 않습니다.


[1.7.2 수정 사항]
- 채팅 메시지가 추가되면 메시지 영역의 스크롤이 최신 대화 위치로 자동 이동하도록 보강했습니다.
- 새 강의방 입장코드를 영문 대문자·숫자 4자리로 생성하도록 변경했습니다.
- 4자리 코드 중복이 감지되면 새 코드를 다시 생성하도록 처리했습니다.
- 기존에 발급된 긴 강의코드도 계속 입력해 입장할 수 있습니다.


[1.7.3 강사·수강생 입장 화면 및 4자리 코드 수정]
- Google 로그인한 강사에게는 수강생용 강의방 입장 폼(강의코드·닉네임)을 숨깁니다.
- 강사는 강의 제목으로 강의방을 만들고, 생성된 4자리 입장코드를 수강생에게 공유합니다.
- 기존 Supabase RPC의 8~32자 코드 길이 검사를 유지하도록 4자리 코드를 내부 저장·조회 시 두 번 이어 붙여 전달합니다. 화면에는 4자리만 표시됩니다.
- 기존 8~32자리 코드도 계속 입장할 수 있습니다.


[1.7.4 Google 강사 권한 자동 등록]
- Google 로그인 계정은 별도 사용자 ID 복사 및 Supabase 수동 INSERT 없이 강사 권한이 자동 등록됩니다.
- 최초 1회 Supabase SQL Editor에서 동봉된 자동 등록 정책 SQL을 실행해야 합니다.
- Google Provider와 본인 user_id만 허용하는 RLS 정책을 사용합니다.
- 강사 계정 화면에서 사용자 ID 복사 UI를 제거했습니다.
