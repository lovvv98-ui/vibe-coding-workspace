"use strict";

const SERVICES_KEY = "services";
const SERVICE_URLS_KEY = "serviceUrls";
const SELECTED_KEY = "selectedServiceId";
const CONFIG_VERSION_KEY = "workspaceConfigVersion";
const CONFIG_VERSION = "1.5.10";
const CLASS_MATERIAL_URL = "https://vibe-coding-workspace-zeta.vercel.app/materials/%EB%B0%94%EC%9D%B4%EB%B8%8C%EC%BD%94%EB%94%A9_%EC%8B%A4%EC%8A%B5%EA%B0%95%EC%9D%98_PPT_%EC%99%80%EC%9D%B4%EB%93%9C%ED%98%95.pdf";

// Chrome allows only one interactive identity.launchWebAuthFlow per extension.
// Keep this lock in the shared service worker so multiple side-panel instances
// cannot start overlapping Google sign-in windows.
let activeGoogleAuthFlow = null;

function launchGoogleAuthFlow(url) {
  if (typeof url !== "string" || !url.startsWith("https://accounts.google.com/")) {
    return Promise.reject(new Error("허용되지 않은 Google 인증 주소입니다."));
  }
  if (activeGoogleAuthFlow) {
    return Promise.reject(new Error("다른 창에서 Google 로그인이 이미 진행 중입니다. 로그인 창을 마친 뒤 다시 시도해주세요."));
  }

  activeGoogleAuthFlow = new Promise((resolve, reject) => {
    chrome.identity.launchWebAuthFlow({ url, interactive: true }, (redirectedTo) => {
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message || "Google 로그인을 완료하지 못했습니다."));
      } else if (!redirectedTo) {
        reject(new Error("Google 로그인 응답이 비어 있습니다."));
      } else {
        resolve(redirectedTo);
      }
    });
  });

  const flow = activeGoogleAuthFlow;
  return flow.finally(() => {
    if (activeGoogleAuthFlow === flow) activeGoogleAuthFlow = null;
  });
}

async function getDefaults() {
  const response = await fetch(chrome.runtime.getURL("data/tools.json"));
  if (!response.ok) throw new Error("기본 서비스 목록을 불러오지 못했습니다.");
  return response.json();
}

async function getServices() {
  const stored = await chrome.storage.local.get([
    SERVICES_KEY,
    SERVICE_URLS_KEY,
    SELECTED_KEY,
    CONFIG_VERSION_KEY
  ]);
  const defaults = await getDefaults();
  let services = Array.isArray(stored[SERVICES_KEY])
    ? [...stored[SERVICES_KEY]]
    : [...defaults];
  const updates = {};

  // Remove the retired built-in Codex tool from existing installations, then
  // add any newly introduced defaults while preserving all other user edits.
  if (stored[CONFIG_VERSION_KEY] !== CONFIG_VERSION) {
    const hadCodex = services.some((service) => service?.id === "codex");
    if (hadCodex) {
      services = services.filter((service) => service?.id !== "codex");
      updates[SERVICES_KEY] = services;
    }

    // Rename the existing personal-page entry for all current installations
    // while preserving its saved URL, enabled state, and user-specific settings.
    const personalPage = services.find((service) => service?.id === "personal-page");
    const personalPageDefault = defaults.find((service) => service.id === "personal-page");
    if (personalPage && personalPageDefault && personalPage.name !== personalPageDefault.name) {
      personalPage.name = personalPageDefault.name;
      personalPage.description = personalPageDefault.description;
      updates[SERVICES_KEY] = services;
    }

    const existingIds = new Set(services.map((service) => service?.id).filter(Boolean));
    defaults.forEach((defaultService, index) => {
      if (existingIds.has(defaultService.id)) return;
      const nextBuiltIn = defaults.slice(index + 1).find((item) => existingIds.has(item.id));
      // The user-requested personal page must be the final row, even after any custom tools.
      if (defaultService.id === "personal-page") {
        services.push(defaultService);
      } else {
        const insertAt = nextBuiltIn
          ? services.findIndex((item) => item.id === nextBuiltIn.id)
          : (defaultService.builtIn ? services.findIndex((item) => !item.builtIn) : -1);
        if (insertAt >= 0) services.splice(insertAt, 0, defaultService);
        else services.push(defaultService);
      }
      existingIds.add(defaultService.id);
    });

    updates[SERVICES_KEY] = services;
    updates[CONFIG_VERSION_KEY] = CONFIG_VERSION;

    if (hadCodex) {
      const savedUrls = stored[SERVICE_URLS_KEY] && typeof stored[SERVICE_URLS_KEY] === "object"
        ? { ...stored[SERVICE_URLS_KEY] }
        : {};
      delete savedUrls.codex;
      updates[SERVICE_URLS_KEY] = savedUrls;
      if (stored[SELECTED_KEY] === "codex") updates[SELECTED_KEY] = null;
    }
  }

  if (Object.keys(updates).length) await chrome.storage.local.set(updates);
  return services;
}

function parseWebUrl(url) {
  try {
    const parsed = new URL(url);
    if (!["http:", "https:"].includes(parsed.protocol) || parsed.username || parsed.password) return null;
    return parsed;
  } catch {
    return null;
  }
}

function matchesService(service, rawUrl) {
  const target = parseWebUrl(service.url);
  const actual = parseWebUrl(typeof rawUrl === "string" ? rawUrl : rawUrl?.url || rawUrl?.pendingUrl || "");
  if (!target || !actual || target.hostname.toLowerCase() !== actual.hostname.toLowerCase()) return false;

  return true;
}

function safeServiceUrl(service, rawUrl) {
  const parsed = parseWebUrl(rawUrl);
  if (!parsed || !matchesService(service, parsed.href)) return null;
  // Keep the page path so the user's project or conversation can be revisited.
  // Query strings and fragments are excluded because they may contain temporary values.
  parsed.search = "";
  parsed.hash = "";
  return parsed.href;
}

function isObject(value) {
  return value && typeof value === "object" && !Array.isArray(value);
}

async function getSavedUrls() {
  const stored = await chrome.storage.local.get(SERVICE_URLS_KEY);
  return isObject(stored[SERVICE_URLS_KEY]) ? stored[SERVICE_URLS_KEY] : {};
}

async function saveCurrentLocation(service, rawUrl, savedUrls = null) {
  const url = safeServiceUrl(service, rawUrl);
  if (!url) return savedUrls || await getSavedUrls();
  const urls = savedUrls || await getSavedUrls();
  if (urls[service.id] !== url) {
    urls[service.id] = url;
    await chrome.storage.local.set({ [SERVICE_URLS_KEY]: urls });
  }
  return urls;
}

async function getWindowTabs() {
  return chrome.tabs.query({ lastFocusedWindow: true });
}

async function getServiceState() {
  const services = await getServices();
  const tabs = await getWindowTabs();
  const activeTab = tabs.find((tab) => tab.active) || null;
  let savedUrls = await getSavedUrls();
  const currentService = services.find((service) => service.enabled && activeTab && matchesService(service, activeTab)) || null;

  if (currentService && activeTab) {
    savedUrls = await saveCurrentLocation(currentService, activeTab.url || activeTab.pendingUrl, savedUrls);
    await chrome.storage.local.set({ [SELECTED_KEY]: currentService.id });
  }

  const statuses = {};
  for (const service of services) {
    if (!service.enabled) {
      statuses[service.id] = { kind: "disabled" };
      continue;
    }
    if (currentService?.id === service.id) {
      statuses[service.id] = { kind: "current" };
      continue;
    }
    const hasOpenTab = tabs.some((tab) => matchesService(service, tab));
    if (hasOpenTab) {
      statuses[service.id] = { kind: "open" };
      continue;
    }
    const remembered = safeServiceUrl(service, savedUrls[service.id]);
    statuses[service.id] = remembered ? { kind: "saved" } : { kind: "ready" };
  }

  return {
    services,
    statuses,
    selectedServiceId: currentService?.id || null,
    currentTabId: activeTab?.id ?? null
  };
}

function isClassMaterialTab(tab) {
  try {
    const actual = new URL(tab?.url || tab?.pendingUrl || "");
    const expected = new URL(CLASS_MATERIAL_URL);
    return actual.origin === expected.origin && actual.pathname === expected.pathname;
  } catch {
    return false;
  }
}

async function openClassMaterial() {
  // Search every browser window so an already-open PDF tab is reused even
  // when it is not in the currently focused window.
  const allTabs = await chrome.tabs.query({});
  const existingTab = allTabs.find(isClassMaterialTab);
  if (existingTab?.id != null) {
    if (existingTab.windowId != null) {
      await chrome.windows.update(existingTab.windowId, { focused: true });
    }
    await chrome.tabs.update(existingTab.id, { active: true });
    return { kind: "activated", tabId: existingTab.id };
  }

  // Create the PDF tab once. Subsequent clicks find and activate this tab.
  const created = await chrome.tabs.create({ url: CLASS_MATERIAL_URL, active: true });
  return { kind: "created", tabId: created.id };
}

async function activateService(serviceId) {
  const services = await getServices();
  const service = services.find((item) => item.id === serviceId && item.enabled);
  if (!service) return { kind: "error", message: "사용할 수 없는 서비스입니다." };

  const tabs = await getWindowTabs();
  const activeTab = tabs.find((tab) => tab.active) || null;
  if (!activeTab?.id) {
    return { kind: "error", message: "브라우저에서 일반 웹페이지 탭을 연 뒤 다시 선택해 주세요." };
  }

  let savedUrls = await getSavedUrls();
  const currentService = services.find((item) => item.enabled && matchesService(item, activeTab));
  if (currentService) {
    savedUrls = await saveCurrentLocation(currentService, activeTab.url || activeTab.pendingUrl, savedUrls);
  }

  if (currentService?.id === service.id) {
    await chrome.storage.local.set({ [SELECTED_KEY]: service.id });
    return { kind: "already-active", tabId: activeTab.id, serviceId: service.id };
  }

  // Reuse an existing service tab anywhere in this browser profile so moving
  // from the PPT window back to ChatGPT restores the original signed-in tab.
  const allTabs = await chrome.tabs.query({});
  const existingTab = allTabs.find((tab) => tab.id !== activeTab.id && matchesService(service, tab));
  if (existingTab) {
    await chrome.storage.local.set({ [SERVICE_URLS_KEY]: savedUrls, [SELECTED_KEY]: service.id });
    if (existingTab.windowId != null) {
      await chrome.windows.update(existingTab.windowId, { focused: true });
    }
    await chrome.tabs.update(existingTab.id, { active: true });
    return { kind: "activated", tabId: existingTab.id, serviceId: service.id };
  }

  // Only create a new tab when the service does not already have one in this window.
  const targetUrl = safeServiceUrl(service, savedUrls[service.id]) || service.url;
  await chrome.storage.local.set({ [SERVICE_URLS_KEY]: savedUrls, [SELECTED_KEY]: service.id });
  const created = await chrome.tabs.create({ url: targetUrl, active: true });
  return { kind: "created", tabId: created.id, serviceId: service.id };
}

async function rememberActiveNavigation(tabId, changeInfo, tab) {
  if (!tab?.active || (!changeInfo.url && changeInfo.status !== "complete")) return;
  try {
    const services = await getServices();
    const service = services.find((item) => item.enabled && matchesService(item, tab));
    if (!service) return;
    await saveCurrentLocation(service, tab.url || tab.pendingUrl);
    await chrome.storage.local.set({ [SELECTED_KEY]: service.id });
  } catch {
    // The side panel requests state again when navigation completes.
  }
}

chrome.runtime.onInstalled.addListener(() => {
  getServices().catch(() => {});
  if (!chrome.sidePanel) return;
  chrome.sidePanel.setOptions({ path: "sidepanel.html", enabled: true }).catch(() => {});
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
});

chrome.tabs.onUpdated.addListener(rememberActiveNavigation);

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  const run = async () => {
    switch (message?.type) {
      case "get-state": return getServiceState();
      case "activate-service": return activateService(message.serviceId);
      case "open-class-material": return openClassMaterial();
      case "launch-google-auth": {
        const redirectedTo = await launchGoogleAuthFlow(message.url);
        return { kind: "auth-complete", redirectedTo };
      }
      default: return { kind: "error", message: "지원하지 않는 요청입니다." };
    }
  };
  run().then(sendResponse).catch((error) => sendResponse({ kind: "error", message: error?.message || "작업을 완료하지 못했습니다." }));
  return true;
});
