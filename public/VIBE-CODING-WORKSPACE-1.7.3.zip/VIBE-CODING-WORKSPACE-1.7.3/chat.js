"use strict";

// VIBE CODING WORKSPACE - Supabase chat integration
// The publishable key is intended for client-side use. Database access is protected by RLS/RPC.
const SB_URL = "https://bmyczvzlmalsrcessbib.supabase.co";
const SB_KEY = "sb_publishable_3XF9EArgkZ2o_Xb9HZzCcg_WlWpT6Uk";
const GOOGLE_CLIENT_ID = "961301130570-l7ues6ki2davp9j02va2jgfv36l7f5vr.apps.googleusercontent.com";
const SESSION_KEY = "vibeChatSupabaseSession";
const ROOM_KEY = "vibeChatCurrentRoom";

const el = (id) => document.getElementById(id);
const chatState = {
  session: null,
  room: null,
  role: null,
  nickname: "",
  createdCode: "",
  members: new Map(),
  memberRefreshPromise: null,
  messages: [],
  socket: null,
  heartbeat: null,
  reconnectTimer: null,
  reconnectDelay: 2500,
  disposed: false,
};

function escapeText(value) {
  return String(value ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
}

function setChatStatus(message, kind = "info") {
  const node = el("chat-status");
  if (!node) return;
  node.textContent = message;
  node.className = `chat-status ${kind}`;
}

function showChatNotice(message, kind = "info") {
  const node = el("chat-alert");
  if (!node) return;
  node.textContent = message;
  node.className = `chat-alert ${kind}`;
  node.hidden = false;
  window.clearTimeout(showChatNotice.timer);
  showChatNotice.timer = window.setTimeout(() => { node.hidden = true; }, 5500);
}

async function storageGet(key) {
  const values = await chrome.storage.local.get(key);
  return values[key] ?? null;
}

async function storageSet(values) {
  await chrome.storage.local.set(values);
}

function apiHeaders(session = null) {
  const headers = {
    apikey: SB_KEY,
    "Content-Type": "application/json",
  };
  if (session?.access_token) headers.Authorization = `Bearer ${session.access_token}`;
  return headers;
}

async function apiRequest(path, options = {}, session = chatState.session) {
  const response = await fetch(`${SB_URL}${path}`, {
    ...options,
    headers: { ...apiHeaders(session), ...(options.headers || {}) },
  });
  const text = await response.text();
  let payload = null;
  try { payload = text ? JSON.parse(text) : null; } catch { payload = { message: text }; }
  if (!response.ok) {
    const message = payload?.msg || payload?.message || payload?.error_description || payload?.error || `요청 실패 (${response.status})`;
    throw new Error(message);
  }
  return payload;
}

function normalizeSession(data) {
  const session = {
    access_token: data.access_token,
    refresh_token: data.refresh_token,
    token_type: data.token_type || "bearer",
    expires_in: data.expires_in || 3600,
    expires_at: data.expires_at || Math.floor(Date.now() / 1000) + (data.expires_in || 3600),
    user: data.user,
  };
  return session;
}

async function saveSession(session) {
  chatState.session = session;
  await storageSet({ [SESSION_KEY]: session });
}

async function refreshSession(session) {
  if (!session?.refresh_token) return null;
  try {
    const data = await apiRequest("/auth/v1/token?grant_type=refresh_token", {
      method: "POST",
      body: JSON.stringify({ refresh_token: session.refresh_token }),
    }, null);
    const next = normalizeSession(data);
    await saveSession(next);
    return next;
  } catch {
    await chrome.storage.local.remove(SESSION_KEY);
    chatState.session = null;
    return null;
  }
}

async function getValidSession() {
  if (!chatState.session) chatState.session = await storageGet(SESSION_KEY);
  if (!chatState.session) return null;
  const expiresAt = Number(chatState.session.expires_at || 0);
  if (expiresAt < Math.floor(Date.now() / 1000) + 60) {
    return await refreshSession(chatState.session);
  }
  return chatState.session;
}

async function signInAnonymously() {
  setChatStatus("수강생 접속을 준비하고 있어요…");
  const data = await apiRequest("/auth/v1/signup", {
    method: "POST",
    body: JSON.stringify({ data: { app: "vibe-coding-workspace" } }),
  }, null);
  if (!data?.access_token || !data?.user?.id) {
    throw new Error("익명 로그인 결과를 확인하지 못했습니다. Supabase의 Anonymous Sign-ins 설정을 확인해주세요.");
  }
  const session = normalizeSession(data);
  await saveSession(session);
  return session;
}

function randomBytesBase64Url(length = 32) {
  const bytes = crypto.getRandomValues(new Uint8Array(length));
  let binary = "";
  bytes.forEach((b) => { binary += String.fromCharCode(b); });
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

async function sha256Hex(value) {
  const bytes = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function launchGoogleIdentityFlow(url) {
  // Route all auth launches through the single background service worker.
  // Chrome permits only one launchWebAuthFlow per extension at a time.
  const response = await chrome.runtime.sendMessage({
    type: "launch-google-auth",
    url,
  });
  if (!response || response.kind === "error") {
    throw new Error(response?.message || "Google 로그인 요청을 시작하지 못했습니다.");
  }
  if (!response.redirectedTo) {
    throw new Error("Google 로그인 응답이 비어 있습니다.");
  }
  return response.redirectedTo;
}

async function signInTeacherWithGoogle() {
  if (!chrome.identity?.launchWebAuthFlow) {
    throw new Error("이 브라우저에서는 확장 프로그램 Google 로그인을 지원하지 않습니다. Chrome 또는 Edge 최신 버전을 사용해주세요.");
  }
  setChatStatus("Google 계정 인증을 진행하고 있어요…");
  const nonce = randomBytesBase64Url(32);
  const state = randomBytesBase64Url(24);
  const hashedNonce = await sha256Hex(nonce);
  // Always use Chrome's canonical redirect URL (including its exact trailing slash).
  const redirectUri = chrome.identity.getRedirectURL();
  const authUrl = new URL("https://accounts.google.com/o/oauth2/auth");
  authUrl.searchParams.set("client_id", GOOGLE_CLIENT_ID);
  authUrl.searchParams.set("response_type", "id_token");
  authUrl.searchParams.set("redirect_uri", redirectUri);
  authUrl.searchParams.set("scope", "openid email profile");
  authUrl.searchParams.set("nonce", hashedNonce);
  authUrl.searchParams.set("state", state);
  authUrl.searchParams.set("prompt", "select_account");

  const redirectResult = await launchGoogleIdentityFlow(authUrl.toString());
  const returnedUrl = new URL(redirectResult);
  const params = new URLSearchParams(returnedUrl.hash.replace(/^#/, ""));
  const error = params.get("error") || returnedUrl.searchParams.get("error");
  if (error) throw new Error(params.get("error_description") || error);
  const returnedState = params.get("state") || returnedUrl.searchParams.get("state");
  if (returnedState !== state) throw new Error("Google 인증 상태값이 일치하지 않습니다. 다시 시도해주세요.");
  const idToken = params.get("id_token");
  if (!idToken) throw new Error("Google ID Token을 받지 못했습니다. OAuth 클라이언트 ID와 Supabase Google Provider 설정을 확인해주세요.");

  const data = await apiRequest("/auth/v1/token?grant_type=id_token", {
    method: "POST",
    body: JSON.stringify({ provider: "google", id_token: idToken, nonce }),
  }, null);
  const session = normalizeSession(data);
  await saveSession(session);
  return session;
}

async function rpc(name, args) {
  const session = await getValidSession();
  if (!session) throw new Error("로그인 세션이 없습니다.");
  return apiRequest(`/rest/v1/rpc/${encodeURIComponent(name)}`, {
    method: "POST",
    body: JSON.stringify(args),
  }, session);
}

function makeRoomCode() {
  // 32-character alphabet avoids confusing I/1 and O/0; four symbols are easy to share.
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = crypto.getRandomValues(new Uint8Array(4));
  return Array.from(bytes, (b) => alphabet[b % alphabet.length]).join("");
}

function normalizeRoomCodeForRpc(value) {
  const code = String(value ?? "").trim().toUpperCase();
  // The current database RPC still enforces an 8-character minimum.
  // New 4-character classroom codes are stored as CODECODE internally,
  // while teachers and students only see and exchange the short code.
  return /^[A-Z0-9]{4}$/.test(code) ? `${code}${code}` : code;
}

async function ensureSessionForJoin() {
  const existing = await getValidSession();
  if (existing) return existing;
  return signInAnonymously();
}

function isGoogleTeacherSession() {
  const user = chatState.session?.user;
  return !!user && !user.is_anonymous;
}

function setUserLine() {
  const user = chatState.session?.user;
  const line = el("chat-user-line");
  if (!line) return;
  if (!user) {
    line.textContent = "수강생은 강의코드와 닉네임만으로 참여할 수 있어요.";
  } else if (user.is_anonymous) {
    line.textContent = "수강생으로 접속 중입니다.";
  } else {
    line.textContent = "강사 계정으로 로그인했습니다. 강의방을 만들 수 있어요.";
  }
}

function renderTeacherState() {
  const isTeacher = isGoogleTeacherSession();
  const user = chatState.session?.user;
  const box = el("teacher-account-box");
  const entryPanel = el("room-entry-panel");
  const loginRow = el("teacher-login-row");
  const createPanel = el("teacher-create-panel");

  // The join form is exclusively for students. A Google-authenticated teacher
  // creates a room first and shares the generated code with students afterward.
  if (entryPanel) entryPanel.hidden = isTeacher || !!chatState.room;
  if (loginRow) loginRow.hidden = isTeacher;
  if (box) box.hidden = !isTeacher;
  if (createPanel) createPanel.hidden = !isTeacher || !!chatState.room;

  if (!isTeacher || !user) return;
  el("teacher-account-email").textContent = user.email || "Google 계정";
  el("teacher-user-id").textContent = user.id;
}

function formatTime(value) {
  try {
    return new Intl.DateTimeFormat("ko-KR", { hour: "2-digit", minute: "2-digit" }).format(new Date(value));
  } catch { return ""; }
}

async function copyMessageText(text) {
  const value = String(text ?? "");
  if (navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(value);
      return;
    } catch {
      // Fall through to the legacy extension-page clipboard fallback.
    }
  }

  const textarea = document.createElement("textarea");
  textarea.value = value;
  textarea.setAttribute("readonly", "");
  textarea.style.position = "fixed";
  textarea.style.opacity = "0";
  textarea.style.pointerEvents = "none";
  document.body.append(textarea);
  textarea.select();
  textarea.setSelectionRange(0, textarea.value.length);
  let copied = false;
  try { copied = document.execCommand("copy"); } finally { textarea.remove(); }
  if (!copied) throw new Error("Clipboard copy was not available.");
}

function scrollMessagesToBottom(list) {
  const moveToBottom = () => {
    if (!list.isConnected) return;
    list.scrollTop = list.scrollHeight;
  };

  // Move immediately, then repeat after the browser has completed layout.
  // This keeps the latest message visible even when the message list changes height.
  moveToBottom();
  requestAnimationFrame(() => {
    moveToBottom();
    requestAnimationFrame(moveToBottom);
  });
}

function renderMessages() {
  const list = el("chat-messages");
  if (!list) return;
  list.replaceChildren();
  if (!chatState.messages.length) {
    const empty = document.createElement("div");
    empty.className = "chat-empty";
    empty.textContent = "아직 대화가 없어요. 첫 메시지를 보내보세요.";
    list.append(empty);
    scrollMessagesToBottom(list);
    return;
  }
  for (const message of chatState.messages) {
    const own = message.sender_id === chatState.session?.user?.id;
    const name = chatState.members.get(message.sender_id) || (own ? chatState.nickname || "나" : "참여자");
    const item = document.createElement("article");
    item.className = `chat-message${own ? " own" : ""}${message.message_type !== "text" ? " special" : ""}${message.message_type === "prompt" ? " prompt" : message.message_type === "notice" ? " notice" : ""}`;
    const typeLabel = message.message_type === "prompt" ? "실습 프롬프트" : message.message_type === "notice" ? "강사 공지" : "";
    item.innerHTML = `
      <div class="chat-message-meta">
        <strong>${escapeText(name)}</strong>
        <div class="chat-message-meta-actions">
          <time>${escapeText(formatTime(message.created_at))}</time>
          <button class="chat-copy-button" type="button" data-copy-message="${escapeText(message.id)}" aria-label="메시지 전체 복사" title="메시지 전체 복사">
            <svg viewBox="0 0 20 20" aria-hidden="true"><rect x="7.2" y="2.8" width="9.5" height="12" rx="1.7"></rect><path d="M5.8 6.2h-.7A1.8 1.8 0 0 0 3.3 8v8.2A1.8 1.8 0 0 0 5.1 18h7.1a1.8 1.8 0 0 0 1.8-1.8v-.4"></path></svg>
          </button>
        </div>
      </div>
      ${typeLabel ? `<div class="chat-message-type ${message.message_type}">${typeLabel}</div>` : ""}
      <div class="chat-message-content">${escapeText(message.content).replace(/\n/g, "<br>")}</div>
    `;
    list.append(item);
  }
  list.querySelectorAll("[data-copy-message]").forEach((button) => {
    button.addEventListener("click", async () => {
      const message = chatState.messages.find((item) => item.id === button.dataset.copyMessage);
      if (!message) return;
      const originalIcon = button.dataset.originalIcon || button.innerHTML;
      button.dataset.originalIcon = originalIcon;
      try {
        await copyMessageText(message.content);
        button.innerHTML = '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="m4.5 10.2 3.4 3.4 7.7-7.8"></path></svg>';
        button.classList.add("copied");
        button.setAttribute("aria-label", "복사 완료");
        button.title = "복사 완료";
        window.setTimeout(() => {
          if (!button.isConnected) return;
          button.innerHTML = originalIcon;
          button.classList.remove("copied");
          button.setAttribute("aria-label", "메시지 전체 복사");
          button.title = "메시지 전체 복사";
        }, 1500);
      } catch {
        showChatNotice("복사하지 못했어요. 브라우저 클립보드 권한을 확인해주세요.", "error");
      }
    });
  });
  scrollMessagesToBottom(list);
}

async function loadRoomData() {
  const room = chatState.room;
  if (!room) return;
  const session = await getValidSession();
  const [members, messages] = await Promise.all([
    apiRequest(`/rest/v1/room_members?select=user_id,nickname,member_role&room_id=eq.${encodeURIComponent(room.id)}`, { method: "GET" }, session),
    apiRequest(`/rest/v1/chat_messages?select=id,room_id,sender_id,message_type,content,created_at&room_id=eq.${encodeURIComponent(room.id)}&order=created_at.asc&limit=100`, { method: "GET" }, session),
  ]);
  chatState.members = new Map((members || []).map((member) => [member.user_id, member.nickname]));
  chatState.role = members?.find((member) => member.user_id === session.user.id)?.member_role || chatState.role || "student";
  chatState.messages = messages || [];
  el("chat-room-title").textContent = room.title;
  el("chat-room-count").textContent = `참여자 ${members.length}명`;
  el("active-room-invite").hidden = !(chatState.role === "teacher" && chatState.createdCode);
  el("active-room-code").textContent = chatState.createdCode || "";
  el("chat-room-panel").hidden = false;
  el("room-entry-panel").hidden = true;
  el("teacher-create-panel").hidden = true;
  el("chat-message-type").hidden = chatState.role !== "teacher";
  el("chat-message-type").value = "text";
  renderMessages();
  setChatStatus(chatState.role === "teacher" ? "강사로 입장했습니다." : "강의방에 입장했습니다.", "success");
  connectRealtime();
}

async function refreshRoomMembers() {
  const roomId = chatState.room?.id;
  if (!roomId) return;
  if (chatState.memberRefreshPromise) return chatState.memberRefreshPromise;

  chatState.memberRefreshPromise = (async () => {
    const session = await getValidSession();
    if (!session) return;
    const members = await apiRequest(
      `/rest/v1/room_members?select=user_id,nickname,member_role&room_id=eq.${encodeURIComponent(roomId)}`,
      { method: "GET" },
      session,
    );
    // Ignore a late response if the user has already moved to another room.
    if (chatState.room?.id !== roomId) return;
    chatState.members = new Map((members || []).map((member) => [member.user_id, member.nickname]));
    chatState.role = members?.find((member) => member.user_id === session.user.id)?.member_role || chatState.role || "student";
    el("chat-room-count").textContent = `참여자 ${(members || []).length}명`;
    renderMessages();
  })();

  try {
    await chatState.memberRefreshPromise;
  } finally {
    chatState.memberRefreshPromise = null;
  }
}

function addRealtimeMessage(message) {
  if (!message?.id || chatState.messages.some((item) => item.id === message.id)) return;
  chatState.messages.push(message);
  renderMessages();
  // A message can arrive just before the member INSERT event. Fetch the sender's
  // nickname as a fallback so the UI never stays on the generic "참여자" label.
  if (message.sender_id && !chatState.members.has(message.sender_id)) {
    refreshRoomMembers().catch((error) => setChatStatus(`참여자 정보를 새로고침하지 못했습니다: ${error.message}`, "error"));
  }
}

function disconnectRealtime() {
  window.clearInterval(chatState.heartbeat);
  window.clearTimeout(chatState.reconnectTimer);
  chatState.heartbeat = null;
  chatState.reconnectTimer = null;
  if (chatState.socket) {
    try { chatState.socket.close(1000, "room changed"); } catch { /* no-op */ }
    chatState.socket = null;
  }
}

function connectRealtime() {
  disconnectRealtime();
  if (!chatState.room || !chatState.session?.access_token) return;
  const socketUrl = new URL(SB_URL.replace(/^https:/, "wss:") + "/realtime/v1/websocket");
  socketUrl.searchParams.set("apikey", SB_KEY);
  socketUrl.searchParams.set("vsn", "2.0.0");
  const topic = `realtime:classroom-${chatState.room.id}`;
  const socket = new WebSocket(socketUrl.toString());
  chatState.socket = socket;
  let ref = 1;

  socket.addEventListener("open", () => {
    const joinPayload = {
      config: {
        broadcast: { ack: false, self: false },
        presence: { enabled: false, key: "" },
        postgres_changes: [
          {
            event: "INSERT",
            schema: "public",
            table: "chat_messages",
            filter: `room_id=eq.${chatState.room.id}`,
          },
          {
            event: "INSERT",
            schema: "public",
            table: "room_members",
            filter: `room_id=eq.${chatState.room.id}`,
          },
          {
            event: "UPDATE",
            schema: "public",
            table: "room_members",
            filter: `room_id=eq.${chatState.room.id}`,
          },
        ],
        private: false,
      },
      access_token: chatState.session.access_token,
    };
    socket.send(JSON.stringify([String(ref), String(ref), topic, "phx_join", joinPayload]));
    chatState.heartbeat = window.setInterval(() => {
      if (socket.readyState === WebSocket.OPEN) {
        ref += 1;
        socket.send(JSON.stringify([null, String(ref), "phoenix", "heartbeat", {}]));
      }
    }, 25000);
    setChatStatus("실시간 연결 중…", "info");
  });

  socket.addEventListener("message", (event) => {
    let payload;
    try { payload = JSON.parse(event.data); } catch { return; }
    let eventName = "";
    let body = {};
    if (Array.isArray(payload)) {
      eventName = payload[3];
      body = payload[4] || {};
    } else {
      eventName = payload.event;
      body = payload.payload || {};
    }
    if (eventName === "phx_reply") {
      const status = body.status || body.response?.status;
      if (status === "ok") setChatStatus("실시간 연결됨", "success");
      if (status === "error") setChatStatus(`실시간 연결 오류: ${body.response?.reason || "구독 실패"}`, "error");
    }
    if (eventName === "postgres_changes") {
      const record = body.data?.record || body.data?.new || body.record;
      const changedTable = body.data?.table;
      if (record?.room_id === chatState.room?.id) {
        if (changedTable === "room_members" || (record?.user_id && record?.nickname)) {
          refreshRoomMembers().catch((error) => setChatStatus(`참여자 목록을 갱신하지 못했습니다: ${error.message}`, "error"));
        } else if (changedTable === "chat_messages" || record?.content !== undefined) {
          addRealtimeMessage(record);
        }
      }
    }
    if (eventName === "system" && body.status === "error") {
      setChatStatus(body.message || "실시간 수신에 문제가 있습니다.", "error");
    }
  });

  socket.addEventListener("close", () => {
    if (chatState.socket !== socket) return;
    window.clearInterval(chatState.heartbeat);
    chatState.heartbeat = null;
    setChatStatus("실시간 연결이 끊겼습니다. 다시 연결을 시도합니다…", "error");
    chatState.reconnectTimer = window.setTimeout(() => {
      if (chatState.room) connectRealtime();
    }, chatState.reconnectDelay);
  });
  socket.addEventListener("error", () => setChatStatus("실시간 서버 연결을 확인하고 있어요…", "info"));
}

async function enterRoom(code, nickname) {
  await ensureSessionForJoin();
  const result = await rpc("join_classroom", { p_code: normalizeRoomCodeForRpc(code), p_nickname: nickname });
  const roomInfo = Array.isArray(result) ? result[0] : result;
  if (!roomInfo?.room_id) throw new Error("강의방 입장 결과를 확인하지 못했습니다.");
  chatState.room = { id: roomInfo.room_id, title: roomInfo.room_title };
  chatState.role = roomInfo.member_role;
  chatState.nickname = nickname;
  chatState.createdCode = "";
  await storageSet({ [ROOM_KEY]: { ...chatState.room, nickname, role: roomInfo.member_role, createdCode: "" } });
  await loadRoomData();
}

async function createRoom(title) {
  const session = await getValidSession();
  if (!session || session.user.is_anonymous) {
    throw new Error("강의방 생성은 Google 로그인한 강사만 가능합니다.");
  }

  // Retry only if a short code is already in use.
  let code = "";
  let result;
  for (let attempt = 0; attempt < 5; attempt += 1) {
    code = makeRoomCode();
    try {
      result = await rpc("create_classroom", { p_title: title, p_code: normalizeRoomCodeForRpc(code) });
      break;
    } catch (error) {
      const isDuplicateCode = /duplicate key|unique constraint|23505|already exists/i.test(String(error?.message || error));
      if (!isDuplicateCode || attempt === 4) throw error;
    }
  }
  if (!result) throw new Error("강의코드를 생성하지 못했습니다. 다시 시도해주세요.");

  chatState.room = { id: result, title };
  chatState.role = "teacher";
  chatState.nickname = "강사";
  chatState.createdCode = code;
  await storageSet({ [ROOM_KEY]: { ...chatState.room, nickname: "강사", role: "teacher", createdCode: code } });
  el("created-room-code").textContent = code;
  el("created-room-card").hidden = false;
  await loadRoomData();
  showChatNotice("강의방을 만들었습니다. 입장코드를 수강생에게 전달하세요.", "success");
}

async function sendMessage() {
  const input = el("chat-message-input");
  const content = input.value.trim();
  if (!content || !chatState.room) return;
  const type = chatState.role === "teacher" ? el("chat-message-type").value : "text";
  const button = el("chat-send-button");
  button.disabled = true;
  try {
    await rpc("send_classroom_message", {
      p_room_id: chatState.room.id,
      p_content: content,
      p_message_type: type,
    });
    input.value = "";
    const before = chatState.messages.length;
    await loadRoomData();
    if (chatState.messages.length === before) {
      // Realtime may be slightly delayed; the next event will add it.
    }
  } catch (error) {
    showChatNotice(error.message, "error");
  } finally {
    button.disabled = false;
    input.focus();
  }
}

async function leaveRoom() {
  disconnectRealtime();
  chatState.room = null;
  chatState.role = null;
  chatState.nickname = "";
  chatState.createdCode = "";
  chatState.messages = [];
  chatState.members.clear();
  await chrome.storage.local.remove(ROOM_KEY);
  el("chat-room-panel").hidden = true;
  renderTeacherState();
  setChatStatus("강의방에서 나왔습니다.");
}

function setBusy(button, busy, busyText = "처리 중…") {
  if (!button) return;
  if (busy) {
    button.dataset.originalText = button.textContent;
    button.textContent = busyText;
    button.disabled = true;
  } else {
    button.textContent = button.dataset.originalText || button.textContent;
    button.disabled = false;
  }
}

async function initializeChat() {
  const savedSession = await storageGet(SESSION_KEY);
  if (savedSession) {
    chatState.session = savedSession;
    try { await getValidSession(); } catch { /* re-auth on next action */ }
  }
  setUserLine();
  renderTeacherState();
  const savedRoom = await storageGet(ROOM_KEY);
  if (savedRoom && chatState.session) {
    chatState.room = { id: savedRoom.id, title: savedRoom.title };
    chatState.nickname = savedRoom.nickname || "";
    chatState.role = savedRoom.role || "student";
    chatState.createdCode = savedRoom.createdCode || "";
    try {
      await loadRoomData();
    } catch (error) {
      await chrome.storage.local.remove(ROOM_KEY);
      chatState.room = null;
      setChatStatus(`이전 강의방을 복원하지 못했습니다: ${error.message}`, "error");
    }
  }
}

function bindChatEvents() {
  el("teacher-signin-button").addEventListener("click", async () => {
    const button = el("teacher-signin-button");
    setBusy(button, true, "Google 로그인 중…");
    try {
      const session = await signInTeacherWithGoogle();
      setUserLine();
      renderTeacherState();
      el("teacher-account-box").hidden = false;
      showChatNotice(`Google 로그인 완료: ${session.user.email || session.user.id}`, "success");
      setChatStatus("강사 계정 인증 완료. 강사 권한 등록 여부를 확인한 뒤 강의방을 만들 수 있어요.", "success");
    } catch (error) {
      const message = String(error?.message || "Google 로그인에 실패했습니다.");
      if (message.includes("Only one web auth flow is allowed at a time")) {
        showChatNotice("다른 창에서 Google 로그인이 이미 진행 중입니다. 로그인 팝업을 닫고 확장 프로그램을 새로고침한 뒤 한 번만 다시 시도해주세요.", "error");
      } else {
        showChatNotice(message, "error");
      }
      setChatStatus("Google 로그인에 실패했습니다.", "error");
    } finally {
      setBusy(button, false);
    }
  });

  el("copy-teacher-id").addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(chatState.session?.user?.id || "");
      showChatNotice("강사 사용자 ID를 복사했습니다.", "success");
    } catch { showChatNotice("사용자 ID 복사에 실패했습니다.", "error"); }
  });

  el("room-code-input").addEventListener("input", (event) => {
    const input = event.currentTarget;
    const start = input.selectionStart;
    const end = input.selectionEnd;
    input.value = input.value.toUpperCase();
    if (start !== null && end !== null) input.setSelectionRange(start, end);
  });

  el("room-entry-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const codeInput = el("room-code-input");
    const code = codeInput.value.trim().toUpperCase();
    codeInput.value = code;
    const nickname = el("nickname-input").value.trim();
    if (!code || !nickname) return showChatNotice("강의코드와 닉네임을 모두 입력해주세요.", "error");
    const button = el("join-room-button");
    setBusy(button, true, "입장 중…");
    try {
      await enterRoom(code, nickname);
      setUserLine();
      showChatNotice("강의방에 입장했습니다.", "success");
    } catch (error) {
      showChatNotice(error.message, "error");
      setChatStatus("강의방에 입장하지 못했습니다.", "error");
    } finally { setBusy(button, false); }
  });

  el("create-room-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const title = el("new-room-title").value.trim();
    if (!title) return showChatNotice("강의 제목을 입력해주세요.", "error");
    const button = el("create-room-button");
    setBusy(button, true, "강의방 생성 중…");
    try {
      await createRoom(title);
      el("new-room-title").value = "";
      setUserLine();
    } catch (error) {
      showChatNotice(error.message, "error");
      if (error.message.includes("강사 권한")) {
        setChatStatus("강사 Google 로그인은 완료됐지만, Supabase에 강사 권한을 등록해야 합니다.", "error");
      }
    } finally { setBusy(button, false); }
  });

  el("chat-send-button").addEventListener("click", sendMessage);
  el("chat-message-input").addEventListener("keydown", (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      sendMessage();
    }
  });
  el("leave-room-button").addEventListener("click", leaveRoom);
  const copyRoomCode = async (value) => {
    if (!value) return showChatNotice("복사할 강의코드가 없습니다.", "error");
    try {
      await navigator.clipboard.writeText(value);
      showChatNotice("강의코드를 복사했습니다.", "success");
    } catch { showChatNotice("강의코드 복사에 실패했습니다.", "error"); }
  };
  el("copy-room-code").addEventListener("click", () => copyRoomCode(el("created-room-code").textContent));
  el("copy-active-room-code").addEventListener("click", () => copyRoomCode(el("active-room-code").textContent));
}

document.addEventListener("DOMContentLoaded", () => {
  bindChatEvents();
  initializeChat().catch((error) => setChatStatus(`채팅 준비 중 오류: ${error.message}`, "error"));
});

window.addEventListener("beforeunload", () => {
  chatState.disposed = true;
  disconnectRealtime();
});
